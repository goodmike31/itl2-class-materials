theInput = input('Type something: ')
print('You typed "',theInput,'"',sep='')

