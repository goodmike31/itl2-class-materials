from func32 import _mySplit

print(_mySplit("Oh, this works too"))

