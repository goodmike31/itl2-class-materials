'''This is a test module.

Author:
	Mike Hammond
Version:
	1 (11/18)
'''

def f(x):
	'''This function doubles its argument.

	Args:
		x: a number to double
	Returns:
		x*2
	'''
	y = x * 2
	return y

