#this doesn't work!

def myfunc():
	word = input('Word: ')
	print('This is your word:',word)

myfunc()
if len(word) < 5:
	print("Your word wasn't long enough")

