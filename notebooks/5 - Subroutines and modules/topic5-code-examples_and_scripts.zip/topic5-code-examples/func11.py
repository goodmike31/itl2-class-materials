#function that takes 2 arguments
def myfunc(a,b):
	#return the concatenation
	#OR addition of those values
	return a + b

#invoke the function with numbers
print(myfunc(3,10))
#invoke the function with strings
print(myfunc('strings ','too'))

