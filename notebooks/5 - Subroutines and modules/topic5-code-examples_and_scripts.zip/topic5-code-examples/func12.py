x = 'a value'

def anotherfunc(a):
	a = 'another value!'
	return a

print(x)
print(anotherfunc(x))
print(x)

