import func30

help(func30.myLen)

