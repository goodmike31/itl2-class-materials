#function definition
def thefunction(x,y):
	return x + ' ' + y

#invoke the function 3 ways
print(thefunction('one','way'))
print(thefunction(x='another',y='way'))
print(thefunction(y='way',x='yet another'))

