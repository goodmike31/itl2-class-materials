def myfunc():            #function definition
	print("This prints.") #prints this
	return 6              #return the value 6
	#gratuitous print command
	print("This doesn't print!")

#invoke function, assign value to x
x = myfunc()
#print value of x
print("Here's the function output:",x)

