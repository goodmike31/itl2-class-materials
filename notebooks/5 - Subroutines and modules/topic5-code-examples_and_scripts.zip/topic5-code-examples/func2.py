def myfunction(): #function definition
	print('This is a function')
	print("That's all it does")

myfunction()      #invoking the function

