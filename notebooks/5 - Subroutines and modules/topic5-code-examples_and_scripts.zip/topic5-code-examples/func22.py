from sys import argv

print(argv)

