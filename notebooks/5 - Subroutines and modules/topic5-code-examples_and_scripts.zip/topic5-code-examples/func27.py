#invoke everything from the module
from func25 import *

#invoke variable without prefix
print(myVar)
#invoke both without prefixes
print(myFunc(myVar))

