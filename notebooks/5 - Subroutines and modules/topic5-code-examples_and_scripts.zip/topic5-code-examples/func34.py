import func32

print(func32._mySplit("Oh, this does work"))

