from sys import argv  #doesn't work!

print(sys.argv)

